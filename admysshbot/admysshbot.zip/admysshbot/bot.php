#!/bin/bash
clear
#--------[ DESENVOLVIDO POR Noobs ]-----------#
source ShellBot.sh
touch lista
[[ -z $1 ]] && {
    clear && echo "INFORME O TOKEN" && exit
}
api_bot=$1
# Seu Dominio
dominio=$2
# Informações Server
ip_server="SEU-IP"
senha_server="SUA-SENHA"
ShellBot.init --token "$api_bot" --monitor --flush --return map
ShellBot.username

# - Funcao menu
menu() {
    local msg
        msg+="<b>🙋‍♂️ OLA ${message_from_first_name[$(ShellBot.ListUpdates)]} SEJA BEM VINDO(a)</b>\n\n"
        msg+="Gere seu teste agora mesmo!"
        ShellBot.sendMessage --chat_id ${message_chat_id[$id]} \
        --text "$(echo -e $msg)" \
        --reply_markup "$keyboard1" \
        --parse_mode html
        return 0
}

# - Funcao criar ssh
criarteste() {
   [[ $(grep -wc ${callback_query_from_id} lista) != '0' ]] && {
      ShellBot.sendMessage --chat_id ${callback_query_message_chat_id} \
        --text "VC JA CRIOU SSH HOJE !"
      return 0
    }
    usuario=$(echo teste$(( RANDOM% + 250 )))
    senha=$((RANDOM% + 99999))
    limite='1'
    tempo='1'
    tuserdate=$(date '+%C%y/%m/%d' -d " +1 days")
    if sshpass -p "$senha_server" ssh -o ConnectTimeout=2 -o StrictHostKeyChecking=no root@$ip_server echo "ok" 1>/dev/null 2>/dev/null; then
		sshpass -p "$senha_server" ssh -o ConnectTimeout=2 -o StrictHostKeyChecking=no root@$ip_server << EOF
		useradd -M -N -s /bin/false $usuario -e $tuserdate > /dev/null 2>&1
    (echo "$senha";echo "$senha") | passwd $usuario > /dev/null 2>&1
    echo "$senha" > /etc/SSHPlus/senha/$usuario
    echo "$usuario $limite" >> /root/usuarios.db
    echo "#!/bin/bash
pkill -f "$usuario"
userdel --force $usuario
grep -v ^$usuario[[:space:]] /root/usuarios.db > /tmp/ph ; cat /tmp/ph > /root/usuarios.db
rm /etc/SSHPlus/senha/$usuario > /dev/null 2>&1
rm -rf /etc/SSHPlus/userteste/$usuario.sh" > /etc/SSHPlus/userteste/$usuario.sh
chmod +x /etc/SSHPlus/userteste/$usuario.sh
at -f /etc/SSHPlus/userteste/$usuario.sh now + $tempo hour > /dev/null 2>&1
EOF
	echo ${callback_query_from_id} >> lista
    # - ENVIA O SSH
    ShellBot.sendMessage --chat_id ${callback_query_message_chat_id} \
    --text "$(echo -e "✅ <b>Teste Criado com sucesso!</b> ✅\n\nIP: $ip_server\nUSUARIO: <code>$usuario</code>\nSENHA: <code>$senha</code>\n\n⏳ Expira em: $tempo Hora")" \
    --parse_mode html
    return 0
else
ShellBot.sendMessage --chat_id ${callback_query_message_chat_id} \
	--text "$(echo -e Erro Tente novamente Mais tarde!)" \
	--parse_mode html
	return 0
fi
}


unset botao1
botao1=''
ShellBot.InlineKeyboardButton --button 'botao1' --line 1 --text '🇧🇷 CRIAR TESTE 🇧🇷' --callback_data 'gerarssh'
ShellBot.InlineKeyboardButton --button 'botao1' --line 3 --text '📲 BAIXAR APP 📲' --callback_data '2' --url "https://t.me/alfainternet" # LINK APP
ShellBot.InlineKeyboardButton --button 'botao1' --line 4 --text '🧑🏼‍💻 SUPORTE 🧑🏼‍💻' --callback_data '3' --url 't.me/alfalemos' # LINK TELEGRAM

ShellBot.regHandleFunction --function criarteste --callback_data gerarssh"

}


while :; do
  [[ "$(date +%d)" != "$(cat RESET)" ]] && {
   	echo $(date +%d) > RESET
   	echo ' ' > lista
  }
  ShellBot.getUpdates --limit 100 --offset $(ShellBot.OffsetNext) --timeout 20
  for id in $(ShellBot.ListUpdates); do
    (
      ShellBot.watchHandle --callback_data ${callback_query_data[$id]}
      comando=(${message_text[$id]})
      [[ "${comando[0]}" = "/menu"  || "${comando[0]}" = "/start" ]] && menu
      [[ "${comando[0]}" = "/teste" ]] && menu
      [[ "${comando[0]}" = "/id"  ]] && infouser
    ) &
  done
done